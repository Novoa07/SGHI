const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./config/database');

const testRoutes = require('./routes/test');

const app = express();
const PORT = 3000;

// Middlewares
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/test', testRoutes);

// Ruta principal
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Ruta de prueba de conexión
app.get('/api/health', async (req, res) => {
  const dbConnected = await db.testConnection();
  res.json({
    status: 'OK',
    database: dbConnected ? 'Connected' : 'Disconnected'
  });
});

// Ruta de prueba simple
app.get('/api/test', (req, res) => {
  res.json({ 
    message: '¡La aplicación funciona!',
    timestamp: new Date().toISOString()
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log('\n🏥 SGHI - Sistema de Gestión Hospitalaria');
  console.log(`🚀 Servidor corriendo en: http://localhost:${PORT}`);
  console.log('Presiona Ctrl+C para detener\n');
});