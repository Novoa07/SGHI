const mysql = require('mysql2');

const dbConfig = {
  host: '192.168.1.13',      
  user: 'sigh',              
  password: '12345678',    
  database: 'SIGH',         
  port: 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
};

const pool = mysql.createPool(dbConfig);
const promisePool = pool.promise();

async function testConnection() {
  try {
    const connection = await promisePool.getConnection();
    console.log('✅ Conexión exitosa a MySQL');
    console.log(`📊 Base de datos: ${dbConfig.database}`);
    console.log(`🌐 Host: ${dbConfig.host}:${dbConfig.port}`);
    connection.release();
    return true;
  } catch (error) {
    console.error('❌ Error de conexión:', error.message);
    console.error('\n💡 Verifica:');
    console.error('   - Que MySQL esté corriendo en la VM');
    console.error('   - La IP y credenciales en config/database.js');
    console.error('   - Que el firewall permita el puerto 3306');
    return false;
  }
}

module.exports = {
  pool: promisePool,
  testConnection
};