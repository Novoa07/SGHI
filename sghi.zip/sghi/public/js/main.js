async function probarConexion() {
    const resultado = document.getElementById('resultado');
    resultado.textContent = 'Probando conexión...';
    resultado.className = '';
    
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        
        if (data.database === 'Connected') {
            resultado.textContent = '✅ Conexión exitosa a la base de datos!';
            resultado.className = 'success';
        } else {
            resultado.textContent = '❌ No se pudo conectar a la base de datos';
            resultado.className = 'error';
        }
    } catch (error) {
        resultado.textContent = '❌ Error: ' + error.message;
        resultado.className = 'error';
    }
}