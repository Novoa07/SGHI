const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Probar consulta simple
router.get('/tablas', async (req, res) => {
  try {
    const [tables] = await db.pool.execute('SHOW TABLES');
    
    res.json({
      success: true,
      message: 'Tablas en la base de datos',
      data: tables
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Probar consulta a una tabla
router.get('/pacientes', async (req, res) => {
  try {
    const [pacientes] = await db.pool.execute('SELECT * FROM PACIENTE LIMIT 5');
    
    res.json({
      success: true,
      count: pacientes.length,
      data: pacientes
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;